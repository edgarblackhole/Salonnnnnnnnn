﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Model1 db = new Model1();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lreg_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            this.Hide();
            f.Show();
        }

        private void bvhod_Click(object sender, EventArgs e)
        {
            if (tlog.Text == "" || tpass.Text == "")
            {
                MessageBox.Show("Нужно задать логин и пароль");
                return;
            }
            Пользователи usr = db.Пользователи.SingleOrDefault(m => m.Логин == tlog.Text);
            if ((usr != null) && (usr.Пароль == tpass.Text))
            {
                if (usr.IDРоли == 1)
                {
                    Form4 admin = new Form4();
                    admin.Show();
                    this.Hide();
                }
                else if (usr.IDРоли == 2)
                {
                    Form3 parih = new Form3();
                    parih.Show();
                    this.Hide();
                }
                else if (usr.IDРоли == 3)
                {
                    Form5 sotr = new Form5();
                    sotr.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show($"Роли{usr.IDРоли} в системе нет");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Пользователя с таким логином и паролем не существует");
                return;
            }

        
    }
    }
}
