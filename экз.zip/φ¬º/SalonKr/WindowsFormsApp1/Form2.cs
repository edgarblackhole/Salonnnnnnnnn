﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        Model1 db = new Model1();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void bvhod_Click(object sender, EventArgs e)
        {
            if (tlog.Text == "" || tpass.Text == "" || trol.Text == null)
            {
                MessageBox.Show("Нужно заполнить все данные");
                return;
            }
            Пользователи usr = db.Пользователи.SingleOrDefault(m => m.Логин == tlog.Text);
            if (usr != null)
            {
                MessageBox.Show("Пользователь с таким логином существует");
                return;
            }
            usr = new Пользователи();
            usr.Логин = tlog.Text;
            usr.Пароль = tpass.Text;
            usr.IDРоли = Convert.ToInt32(trol.Text);
            db.Пользователи.Add(usr);
            try
            {
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            MessageBox.Show("Пользователь" + usr.Логин + "Зарегистрирован");
            Form1 auth = new Form1();
            this.Close();
            return;
        }
    
    }
}
